import {Text, View, TextInput, TouchableOpacity} from 'react-native'
import React, {useState} from 'react'

export default function TaskList(){
  const [task, setTask] = useState([
    "Coder", "Dat lich kham benh"
  ])

  let newTask = '';
  
  const addTask = (task : string) =>{
      
  }

  const saveTask = ( task: string)=>{
    newTask = task;
  }

  const removeTask = (taskName : string) => {
  }

  
  return(
    <View style={{flex:4, alignItems:'center'}}>
        <Text style={{fontWeight:500}}>Cac cong viec hien tai</Text>
        {
          task.map(t => {
            return(
              <View style={{flexDirection:'row'}}>
                <Text>{t} </Text>
                <TouchableOpacity style={{borderWidth:1, paddingHorizontal:2, backgroundColor:'red'}}>
                  <Text style={{color:'white'}}>Delete</Text>
                </TouchableOpacity>
              </View>
            )
          })
        }
      </View>
  )
}
import {Text, View, TextInput, TouchableOpacity} from 'react-native'
import TaskList from './components/TaskList'

export default function App(){
  return (
    <View style={{flex:1}}>
      <View style={{flex:1, margin:20}}>
        <Text style={{marginBottom:10}}>Nhập công việc</Text>
        <TextInput id="task" value="" placeholder="//Type here" style={{backgroundColor:'gray', padding:5, color: "white"}}/>
      </View>

      <View style={{flex:1, justifyContent: 'center',
            alignItems: 'center',}}>
        <TouchableOpacity style={{
          backgroundColor: 'green',
            borderRadius: 5,
            height: 45,
            width: '80%',
            justifyContent: 'center',
            alignItems: 'center',
        }} onPress={() => {}}>
          <Text style={{fontSize:20, fontWeight:400, color:"white"}}>Them</Text>
        </TouchableOpacity>
      </View>

      <TaskList />
    </View>
  )
}